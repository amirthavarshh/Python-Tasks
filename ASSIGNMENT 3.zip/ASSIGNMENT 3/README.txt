http://127.0.0.1:8000/register/ to Register
http://127.0.0.1:8000/login/ to Login

After login, you will be redirected to the dashboard.
